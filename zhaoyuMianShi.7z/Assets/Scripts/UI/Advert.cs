using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Advert : UIManager
{
    
    public override void  Start()
    {
        base.Start();
    }

    
   
}

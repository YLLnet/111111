using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text;
using UnityEngine.UI;
using System;
public class UIManager : MonoBehaviour
{
    
    public static UIManager Ins;
    public static Dictionary<string, UIManager> viewDict = new Dictionary<string, UIManager>();
    public virtual void Start()
    {
        Debug.Log(this.GetType().ToString());
        gameObject.name = this.GetType().ToString();
        AddBaseDict();
        //Player.Ins.infoSyncToUI += SyncInfo;
    }

    public void AddBaseDict()
    {
        if (!viewDict.ContainsKey(gameObject.name))
        {
            viewDict.Add(gameObject.name, this);
        }
    }

    public static void Show(string viewName)
    {
        foreach (var item in viewDict)
        {
            if (viewName == item.Key)
            {
                item.Value.Show();
                break;
            }
        }
    }

    public static void Hide(string viewName)
    {
        foreach (var item in viewDict)
        {
            if (viewName == item.Key)
            {
                item.Value.Hide();
                break;
            }
        }
    }

    public virtual void Show()
    {
        gameObject.SetActive(true);
    }

    public virtual void Hide()
    {
        gameObject.SetActive(false);
    }

   

   
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;


 /// <summary>
 /// �����
 /// </summary>
public class Pool : MonoBehaviour
{
    private static Pool pool;

    public static Pool Instance
    {
        get
        {
            return pool;
        }

        set { pool = value; }
    }

 

    Dictionary<string, Stack<GameObject>> GameObjectPool;
    void Awake()
    {
        pool = this;
        GameObjectPool = new Dictionary<string, Stack<GameObject>>();
        DontDestroyOnLoad(gameObject);
    }


    public void Recovery(GameObject obj)
    {
        string name = obj.name.Replace(" ", "");

        if (!GameObjectPool.ContainsKey(name))
        {
            GameObjectPool.Add(name, new Stack<GameObject>());
        }

        GameObjectPool[name].Push(obj);
        obj.SetActive(false);
        obj.transform.SetParent(transform, false);

    }

    public GameObject OutPool(string prefabObjName)
    {
        GameObject obj = null;
        if (GameObjectPool.ContainsKey(prefabObjName))
        {

            if (GameObjectPool[prefabObjName].Count > 0)
            {
                obj = GameObjectPool[prefabObjName].Pop();
                obj.name = prefabObjName;
                obj.SetActive(true);
                return obj;
            }
        }

        try
        {
            obj = Instantiate(Resources.Load<GameObject>("Prefab/" + prefabObjName));
        }
        catch (System.Exception e)
        {
            Debug.Log(e.Message);
        }

        obj.name = prefabObjName;
        obj.SetActive(true);
        return obj;
    }
    

    public GameObject OutPool(string prefabObjName, Transform parent)
    {
        GameObject obj = null;
        if (GameObjectPool.ContainsKey(prefabObjName))
        {
            if (GameObjectPool[prefabObjName].Count > 0)
            {
                obj = GameObjectPool[prefabObjName].Pop();
                obj.name = prefabObjName;
                obj.transform.SetParent(parent, false);
                obj.SetActive(true);
                return obj;
            }
        }

        try
        {
            obj = Instantiate(Resources.Load<GameObject>("Prefab/" + prefabObjName));
        }
        catch (System.Exception e)
        {
            Debug.Log(e.Message);
        }

        obj.name = prefabObjName;
        obj.transform.SetParent(parent, false);
        obj.SetActive(true);
        return obj;
    }



    public T OutPool<T>(string prefabObjName,Transform parent = null)
    {
        GameObject obj = null;
        if (GameObjectPool.ContainsKey(prefabObjName))
        {
            if (GameObjectPool[prefabObjName].Count > 0)
            {
                obj = GameObjectPool[prefabObjName].Pop();
                obj.name = prefabObjName;
                obj.transform.SetParent(parent, false);
                obj.SetActive(true);
                return obj.GetComponent<T>();
            }
        }

        try
        {
            obj = Instantiate(Resources.Load<GameObject>("Prefab/" + prefabObjName));
        }
        catch (System.Exception e)
        {
            Debug.Log(e.Message);
        }
        obj.name = prefabObjName;
        obj.transform.SetParent(parent, false);
        obj.SetActive(true);
        return obj.GetComponent<T>();
    }



}

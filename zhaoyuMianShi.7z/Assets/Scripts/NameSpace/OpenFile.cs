using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Runtime.InteropServices;
using System.Text;

namespace System.IO
{
    public class OpenFile
    {
        private static OpenFile openFile;

        private static Texture2D texture;
        public static OpenFile Instance
        {
            get
            {
                if (openFile == null)
                {
                    openFile = new OpenFile();
                }
                return openFile;
            }
            set { openFile = value; }
        }


        [DllImport("Comdlg32.dll", SetLastError = true, ThrowOnUnmappableChar = true, CharSet = CharSet.Auto)]
        private static extern bool GetOpenFileName([In, Out] OpenFileName ofn);
        [DllImport("Comdlg32.dll", SetLastError = true, ThrowOnUnmappableChar = true, CharSet = CharSet.Auto)]
        private static extern bool GetSaveFileName([In, Out] OpenFileName ofd);
        [DllImport("shell32.dll", SetLastError = true, ThrowOnUnmappableChar = true, CharSet = CharSet.Auto)]

        private static extern IntPtr SHBrowseForFolder([In, Out] DirName ofn);//�������

        [DllImport("shell32.dll", SetLastError = true, ThrowOnUnmappableChar = true, CharSet = CharSet.Auto)]
        private static extern bool SHGetPathFromIDList([In] IntPtr pidl, [In, Out] char[] fileName);//���������ѡ���·��

        /// <summary>
        /// ѡ���ļ�
        /// </summary>
        /// <returns></returns>
        [Obsolete]
        public static bool SelectFile(string selectPath,Action finish,ref string filePath)
        {

            OpenFileName ofn = new OpenFileName();

            ofn.structSize = Marshal.SizeOf(ofn);

            ofn.filter = "ͼƬ�ļ�(*.jpg*.png)\0*.jpg;*.png";

            ofn.file = new string(new char[256]);//ѡ����ļ���Ч·��
            filePath = ofn.file;


            ofn.maxFile = ofn.file.Length;


            ofn.fileTitle = new string(new char[64]);
            ofn.maxFileTitle = ofn.fileTitle.Length;
            string path = selectPath;


            path = path.Replace('/', '\\');
            //Ĭ��·��    ����·��
            ofn.initialDir = path;
            ofn.title = "Open Project";


            ofn.defExt = "JPG";//��ʾ�ļ�������
                               //ע�� һ����Ŀ��һ��Ҫȫѡ ����0x00000008�Ҫȱ��
            ofn.flags = 0x00080000 | 0x00001000 | 0x00000800 | 0x00000200 | 0x00000008;//OFN_EXPLORER|OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST| OFN_ALLOWMULTISELECT|OFN_NOCHANGEDIR

            bool open = WindowDll.GetOpenFileName(ofn);
            if (open)
            {
                finish();    
            }
            return open;
        }


        /// <summary>
        /// ͼƬѡ���
        /// </summary>
        public static bool SelectFile(string selectPath, ref string filePath)
        {
            OpenFileName ofn = new OpenFileName();

            ofn.structSize = Marshal.SizeOf(ofn);

            ofn.filter = "ͼƬ�ļ�(*.jpg*.png)\0*.jpg;*.png";

            ofn.file = new string(new char[256]);//ѡ����ļ���Ч·��     
            filePath = ofn.file;
            ofn.maxFile = ofn.file.Length;

            ofn.fileTitle = new string(new char[64]);
            ofn.maxFileTitle = ofn.fileTitle.Length;


            //path = path.Replace('/', '\\');
            selectPath = selectPath.Replace("/",@"\");
            Debug.Log(selectPath);
            //Ĭ��·��    ����·��
            ofn.initialDir = @selectPath;
           
            ofn.title = "Open Project";

            ofn.defExt = "JPG";//��ʾ�ļ�������
                               //ע�� һ����Ŀ��һ��Ҫȫѡ ����0x00000008�Ҫȱ��
            ofn.flags = 0x00080000 | 0x00001000 | 0x00000800 | 0x00000200 | 0x00000008;//OFN_EXPLORER|OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST| OFN_ALLOWMULTISELECT|OFN_NOCHANGEDIR

            bool open = WindowDll.GetOpenFileName(ofn);

            return open;
        }

        public static string WindowsPath(string path)
        {
            return  path.Replace("/", @"\");
        }
      

        /// <summary>
        /// ���ļ��������  ѡ���᷵���ļ��е�·��
        /// </summary>
        public static string GetDir()
        {
            DirName d = new DirName();
            IntPtr i = SHBrowseForFolder(d);
            char[] c = new char[256];

            SHGetPathFromIDList(i, c);


            //Debug.Log(!Directory.Exists(new string(@c)));
            return CharToStr(new string(c));
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private class DirName
        {
            public IntPtr hwndOwner = IntPtr.Zero;
            public IntPtr pidlRoot = IntPtr.Zero;
            public string pszDisplayName = null;
            public string lpszTitle = null;
            public uint ulFlags = 0;
            public IntPtr lpfn = IntPtr.Zero;
            public IntPtr lParam = IntPtr.Zero;
            public int iImage = 0;
            public DirName()
            {
                pszDisplayName = new string(new char[256]);
                ulFlags = 0x00000040 | 0x00000010; //BIF_NEWDIALOGSTYLE | BIF_EDITBOX;
                lpszTitle = "��Ŀ¼";
            }
        }

        /// <summary>
        /// ��/ִ���ļ�
        /// </summary>
        public static void OpenFolder(string path)
        {
            using (System.Diagnostics.Process.Start(path))
            {
               
            }
        }


        /// <summary>
        /// �����ļ���
        /// </summary>
        public static void CreatePath(string path)
        {
            if (!Directory.Exists(WindowsPath(path)))
            {
                Directory.CreateDirectory(WindowsPath(path));
            }
        }

        /// <summary>
        /// ������ִ���ļ�
        /// </summary>
        /// <param name="path"></param>
        public static void CreateEXE(string path)
        {
           
            if (!File.Exists(WindowsPath(path)))
            {
                File.Create(WindowsPath(path));
                Debug.Log("CreateEXE:" + WindowsPath(path));
            }
        }



        public static void Copy(string sourceFileName, string destFileName)
        {

            byte[] bytes = GetBytes(sourceFileName);


            BytesToFile(GetBytes(sourceFileName), destFileName);

        }
        public static void BytesToFile(byte[] bytes, string path)
        {
            try
            {
                // �ļ�������ɾ��
                if (System.IO.File.Exists(path)) { System.IO.File.Delete(path); }

                // д���ļ�����ʽһ
                using (FileStream fs = new FileStream(path, FileMode.CreateNew))
                {
                    using (BinaryWriter bw = new BinaryWriter(fs))
                    {
                        bw.Write(bytes, 0, bytes.Length);
                    }
                }

                // д���ļ�����ʽ��
                //System.IO.File.WriteAllBytes(path, bytes);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// �������ļ�ת���ֽ�
        /// </summary>
        public static byte[] GetBytes(string path)
        {
            Debug.Log(CharToStr(path));
            FileStream fs = new FileStream(CharToStr(path), FileMode.Open, FileAccess.Read);
            try
            {
                byte[] buffur = new byte[fs.Length];
               
                Debug.Log(fs.Read(buffur, 0, (int)fs.Length));
                return buffur;
            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
                if (fs != null)
                {
                    //�ر���Դ
                    fs.Close();
                }
            }
        }

        /// <summary>
        /// ��Ч·��
        /// </summary>
        public static string CharToStr(string filePath)
        {
            int len = 0; string path = "";
            foreach (var item in filePath) if (item != (char)0) len++;

            for (int i = 0; i < len; i++) path += filePath[i];

            return path;
        }

        /// <summary>
        /// �ֽ�תsprite
        /// </summary>
        public static Sprite BytesToSprite(byte[] bytes)
        {
            //�ȴ���һ��Texture2D�������ڰ�������ת��Texture2D
            Texture2D texture = new Texture2D(10, 10);
            texture.LoadImage(bytes);//������ת����Texture2D
                                     //����һ��Sprite,��Texture2D����Ϊ��
            Sprite sp = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), Vector2.zero);
            return sp;
        }
        /// <summary>
        /// �ֽ�תTexture
        /// </summary>
        public static Texture2D BytesToTexture2D(byte[] bytes)
        {
            //�ȴ���һ��Texture2D�������ڰ�������ת��Texture2D
            Texture2D texture = new Texture2D(10, 10);
            texture.LoadImage(bytes);//������ת����Texture2D
                                     //����һ��Sprite,��Texture2D����Ϊ                                     
                                     //Sprite sp = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), Vector2.zero);
            return texture;
        }

        /// <summary>
        /// �ֽ�תTexture
        /// </summary>
        public static Sprite Texture2DToSprite(Texture2D texture)
        {
            //�ȴ���һ��Texture2D�������ڰ�������ת��Texture2D
            //������ת����Texture2D
            //����һ��Sprite,��Texture2D����Ϊ                                     
            Sprite sp = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), Vector2.zero);
            return sp;
        }


        /// <summary>
        /// Component<Image>().sprite =>  FilePath
        /// </summary>
        public static void ImageToSprite(string path, Image _image)
        {
            texture = new Texture2D(0, 0);
            FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
            byte[] bytes = new byte[fileStream.Length];

            fileStream.Read(bytes, 0, bytes.Length);
            fileStream.Close();
            texture.LoadImage(bytes);//������ת����Texture2D
                                     //����һ��Sprite,��Texture2D����Ϊ����
            _image.sprite = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), Vector2.zero);
        }


        

        [Obsolete]
        public IEnumerator Load(string path)
        {
            Debug.Log(File.Exists(path));
            Debug.Log(path);
            // WWW www = new WWW("file:///C:\\fast-neural-style-tensorflow-master\\generated\\res.jpg");
            WWW www = new WWW("file:///" + path);
            Debug.Log("file:///" + path);
            Debug.Log(www.isDone);
            yield return www;

            if (www != null && string.IsNullOrEmpty(www.error))
            {
                Debug.Log(1);
                //��ȡTexture
                Texture2D texture = www.texture;
                //�������...
                //ֱ�ӽ�ѡ��ͼ����
                byte[] bytes = texture.EncodeToJPG();
                Debug.Log(bytes.Length);
                string filename = Application.streamingAssetsPath + "/1.jpg";
                System.IO.File.WriteAllBytes(filename, bytes);
                Sprite sprite = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), new Vector2(0.5f, 0.5f));
            }
        }

    }


    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]


    public class OpenFileName
    {
        public int structSize = 0;//�ṹ�ߴ�
        public IntPtr dlgOwner = IntPtr.Zero;
        public IntPtr instance = IntPtr.Zero;
        public String filter = null;
        public String customFilter = null;
        public int maxCustFilter = 0;
        public int filterIndex = 0;
        public String file = null;
        public int maxFile = 0;
        public String fileTitle = null;
        public int maxFileTitle = 0;
        public String initialDir = null;
        public String title = null;
        public int flags = 0;
        public short fileOffset = 0;
        public short fileExtension = 0;
        public String defExt = null;
        public IntPtr custData = IntPtr.Zero;
        public IntPtr hook = IntPtr.Zero;
        public String templateName = null;
        public IntPtr reservedPtr = IntPtr.Zero;
        public int reservedInt = 0;
        public int flagsEx = 0;
    }


    public class WindowDll
    {
        [DllImport("Comdlg32.dll", SetLastError = true, ThrowOnUnmappableChar = true, CharSet = CharSet.Auto)]
        public static extern bool GetOpenFileName([In, Out] OpenFileName ofn);
        public static bool GetOpenFileName1([In, Out] OpenFileName ofn)
        {
            return GetOpenFileName(ofn);
        }


        [DllImport("Comdlg32.dll", SetLastError = true, ThrowOnUnmappableChar = true, CharSet = CharSet.Auto)]
        public static extern bool SelectedFileDialog([In, Out] OpenFileName ofn);
        public static bool SaveFileDialog1([In, Out] OpenFileName ofn)
        {
            return SelectedFileDialog(ofn);
        }
    }

}


